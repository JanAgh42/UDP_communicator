from random import randint

used_ids = list()

def new_id() -> int:
    transfer_id = -1

    while True:
        transfer_id = randint(1, 65535)

        if transfer_id not in used_ids:
            break
    
    return transfer_id

def remove_id(id: int) -> None:
    if id in used_ids:
        used_ids.remove(id)