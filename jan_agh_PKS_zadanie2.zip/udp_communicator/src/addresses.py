own_ip = ""
own_port = 0

foreign_ip = ""
foreign_port = 0